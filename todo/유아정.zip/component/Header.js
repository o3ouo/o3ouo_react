export default function Header({ filter, setFilter, allDelete }) {

  console.log(`Filter : ${filter}`)
  
  return (
    <header className="header">

      <div className="inner">
        <h1>TO-DO LIST</h1>

        <div className="btn-box">
          <button 
            type="button" 
            onClick={() => setFilter('All List')}
            disabled={filter === 'All List'}
          >All List</button>
          <button 
            type="button" 
            onClick={() => setFilter('Completed List')}
            disabled={filter === 'Completed List'}
          >Completed List</button>
          <button 
            type="button" 
            onClick={() => setFilter('Unfinished List')}
            disabled={filter === 'Unfinished List'}
          >Unfinished List</button>
          <button 
            type="button" 
            onClick={allDelete}
          >All Delete</button>
        </div>

      </div>

    </header>
  );
}