import TodoItem from "./TodoItem";

export default function TodoList({todos, removeTodo, changeCheck }) {

  return (
    <div className="list-wrap">
      <ul>
        {
          todos.map((list, idx) => (
            <TodoItem key={idx} idx={idx} list={list} removeTodo={removeTodo} changeCheck={changeCheck}/>
          ))
        }
      </ul>
    </div>
  );
}