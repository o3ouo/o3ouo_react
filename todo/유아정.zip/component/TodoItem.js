import React, { useState, useEffect } from 'react';

export default function TodoItem({ idx, list, removeTodo, changeCheck }) {


  return (
    <li className="list">
      <input 
        type="checkbox"
        checked={list.checked}
        onChange={() => changeCheck(idx)}
        />
      <p 
        style={{
          textDecoration: list.checked ? 'line-through':'none', 
          color: list.checked ? 'gray' : 'black'
        }}
      >
        {list.inputText}
      </p>
      <button type="button" onClick={() => removeTodo(idx)}>Delete</button>
    </li>
  );
}

