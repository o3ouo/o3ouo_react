import './App.css';
import React, { useState, useEffect } from 'react';
import Header from './component/Header';
import Input from './component/Input';
import TodoList from './component/TodoList';


function App() {

  const [todos, setTodos] = useState([]);
  const [filter, setFilter] = useState('All List');

  // add todo
  const addTodo = (inputText) => { 
    const newTodo = {inputText, edit: false, checked: false};
    setTodos([...todos, newTodo]);
  };

  // delete todo
  const removeTodo = (index) => {
    const newTodo = todos.filter((_ , idx) => index !== idx)
    setTodos(newTodo);
  }

  // checked
  const changeCheck = (checkItem) => {
    setTodos(todos.map((todo, idx) => 
      idx === checkItem ? {...todo, checked: !todo.checked} : todo
    ));
  }

  // menu filter
  const filterTodo = todos.filter((todo) => {
    if (filter === 'Completed List') return todo.checked;
    if (filter === 'Unfinished List') return !todo.checked;
    return true;
  })

  // All Delete
  const allDelete = () => {
    setTodos([]);
  }



  return (
    <div className="App">
      <div className="inner">
        
        <Header filter={filter} setFilter={setFilter} allDelete={allDelete}/>
        
        <Input addTodo={addTodo}/>

        <TodoList todos={filterTodo} removeTodo={removeTodo} changeCheck={changeCheck} />
        
      </div>

    </div>
  );
}

export default App;
